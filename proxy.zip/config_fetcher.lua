local http = require "resty.http"

-- Получаем список серверов из переменной окружения
local servers_str = os.getenv("SERVERS")
local subscribe_title = os.getenv("SUBSCRIBE_TITLE")

if not servers_str then
    ngx.log(ngx.ERR, "No servers found in environment variable")
    ngx.exit(ngx.HTTP_INTERNAL_SERVER_ERROR)
end

-- Разделяем строку на таблицу серверов
local servers = {}
for server in string.gmatch(servers_str, "[^%s]+") do
    table.insert(servers, server)
end

local httpc = http.new()
local configs = {}

-- Переменные для подсчета статистики
local total_upload = 0
local total_download = 0
local total_traffic = 0
local min_expire = nil

-- Запрашиваем конфигурацию с каждого сервера
for _, base_url in ipairs(servers) do
    local url = base_url .. ngx.var.sub_id
    local res, err = httpc:request_uri(url, {
        method = "GET",
        ssl_verify = false,  -- Параметр для пропуска проверки SSL-сертификатов (если необходимо)
    })

    if res and res.status == 200 then
        -- Обработка заголовков статистики
        local userinfo = res.headers["Subscription-Userinfo"]
        if userinfo then
            local upload = tonumber(string.match(userinfo, "upload=(%d+)")) or 0
            local download = tonumber(string.match(userinfo, "download=(%d+)")) or 0
            local total = tonumber(string.match(userinfo, "total=(%d+)")) or 0
            local expire = tonumber(string.match(userinfo, "expire=(%d+)")) or 0

            total_upload = total_upload + upload
            total_download = total_download + download
            total_traffic = total_traffic + total

            if expire > 0 then
                if not min_expire or expire < min_expire then
                    min_expire = expire
                end
            end
        end

        -- Декодируем ответ
        local decoded_config = ngx.decode_base64(res.body)
        if decoded_config then
            table.insert(configs, decoded_config)
        else
            ngx.log(ngx.ERR, "Failed to decode base64 from ", url)
        end
    else
        ngx.log(ngx.ERR, "Error fetching from ", url, ": ", err)
    end
end

-- Возвращаем объединённые конфигурации клиенту
if #configs > 0 then
    -- Устанавливаем заголовки
    local final_expire = min_expire or 0
    local userinfo_header = string.format("upload=%d; download=%d; total=%d; expire=%d", 
        total_upload, total_download, total_traffic, final_expire)
    
    ngx.header["Subscription-Userinfo"] = userinfo_header
    
    if subscribe_title and subscribe_title ~= "" then
        ngx.header["Profile-Title"] = "base64:" .. ngx.encode_base64(subscribe_title)
    end

    -- Объединяем без добавления новой строки между конфигурациями
    local combined_configs = table.concat(configs)
    local encoded_combined_configs = ngx.encode_base64(combined_configs)
    ngx.header.content_type = "text/plain; charset=utf-8" -- Устанавливаем Content-Type
    ngx.print(encoded_combined_configs) -- Возвращаем клиенту результат без лишней новой строки
else
    ngx.status = ngx.HTTP_BAD_GATEWAY
    ngx.say("No configs available")
end
